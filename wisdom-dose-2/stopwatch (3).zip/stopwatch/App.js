import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, Pressable, FlatList, StyleSheet, TextInput } from 'react-native';
import { Audio } from 'expo-av';

// Reliable short alarm WAV (tested in Expo Go)
const ALARM_SOUND = {
  uri: 'https://assets.mixkit.co/sfx/preview/mixkit-alarm-tones-3328.wav',
};

// Format time as MM:SS:MS
const formatTime = (ms) => {
  const totalMs = Math.max(0, Math.floor(ms));
  const minutes = Math.floor(totalMs / 60000);
  const seconds = Math.floor((totalMs % 60000) / 1000);
  const milliseconds = Math.floor((totalMs % 1000) / 10);
  return `${minutes.toString().padStart(2, '0')}:${seconds
    .toString()
    .padStart(2, '0')}.${milliseconds.toString().padStart(2, '0')}`;
};

// Timer Hook
const useTimer = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [isCountdown, setIsCountdown] = useState(false);
  const [time, setTime] = useState(0);
  const [inputSeconds, setInputSeconds] = useState('');
  const [laps, setLaps] = useState([]);
  const [startTimestamp, setStartTimestamp] = useState(null);
  const [flashActive, setFlashActive] = useState(false);
  const [borderFlash, setBorderFlash] = useState(null);
  const [sound, setSound] = useState(null);
  const [soundLoaded, setSoundLoaded] = useState(false);

  const triggerBorderFlash = useCallback((color) => {
    setBorderFlash(color);
    setTimeout(() => setBorderFlash(null), 300);
  }, []);

  // Load sound on mount
  useEffect(() => {
    let isMounted = true;
    const loadSound = async () => {
      try {
        console.log('Loading sound with expo-av...');
        const { sound } = await Audio.Sound.createAsync(ALARM_SOUND, { shouldPlay: false });
        if (isMounted) {
          setSound(sound);
          setSoundLoaded(true);
          console.log('Sound loaded successfully');
        }
      } catch (error) {
        console.error('Sound load failed:', error);
      }
    };
    loadSound();
    return () => {
      isMounted = false;
      if (sound) {
        sound.unloadAsync().catch(console.warn);
      }
    };
  }, []);

  // Play sound
  const playAlarmSound = useCallback(async () => {
    if (!soundLoaded || !sound) {
      console.warn('Sound not loaded, skipping playback');
      return;
    }
    try {
      console.log('Playing sound...');
      await sound.replayAsync();
      console.log('Sound played successfully');
    } catch (error) {
      console.error('Sound playback failed:', error);
    }
  }, [soundLoaded, sound]);

  useEffect(() => {
    let interval;
    if (isRunning && startTimestamp) {
      interval = setInterval(() => {
        const now = Date.now();
        const elapsed = now - startTimestamp;
        if (isCountdown) {
          const target = parseInt(inputSeconds || '0') * 1000;
          const remaining = Math.max(0, target - elapsed);
          setTime(remaining);
          if (remaining <= 0) {
            setIsRunning(false);
            setTime(0);
            setLaps([]);
            setStartTimestamp(null);
            setFlashActive(true);
            playAlarmSound(); // Play sound on completion
            setTimeout(() => setFlashActive(false), 400);
          }
        } else {
          setTime(elapsed);
        }
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isRunning, isCountdown, startTimestamp, inputSeconds, playAlarmSound]);

  const startStop = useCallback(() => {
    if (isRunning) {
      setIsRunning(false);
      setStartTimestamp(null);
      triggerBorderFlash('#ff3333');
    } else {
      if (isCountdown && (!inputSeconds || parseInt(inputSeconds) <= 0)) return;
      setStartTimestamp(Date.now());
      if (isCountdown && time === 0) {
        setTime(parseInt(inputSeconds) * 1000);
      }
      setIsRunning(true);
      triggerBorderFlash('#33cc33');
    }
  }, [isRunning, isCountdown, inputSeconds, time, triggerBorderFlash]);

  const reset = useCallback(() => {
    setIsRunning(false);
    setTime(0);
    setInputSeconds('');
    setLaps([]);
    setStartTimestamp(null);
    setFlashActive(false);
  }, []);

  const addLap = useCallback(() => {
    if (isRunning) {
      setLaps((prev) => [...prev, time]);
      triggerBorderFlash('#3b82f6');
    }
  }, [isRunning, time, triggerBorderFlash]);

  const toggleMode = useCallback(() => {
    setIsCountdown((prev) => !prev);
    reset();
  }, [reset]);

  const setCountdown = useCallback((text) => {
    const nums = text.replace(/[^0-9]/g, '');
    setInputSeconds(nums);
    if (!isRunning) {
      setTime(parseInt(nums || '0') * 1000);
    }
  }, [isRunning]);

  return {
    isRunning, isCountdown, time, inputSeconds, laps,
    startStop, reset, addLap,
    deleteLap: (i) => setLaps((prev) => prev.filter((_, idx) => idx !== i)),
    toggleMode, setCountdown, flashActive, borderFlash
  };
};

// Main App
export default function App() {
  const {
    isRunning, isCountdown, time, inputSeconds, laps,
    startStop, reset, addLap, deleteLap, toggleMode, setCountdown,
    flashActive, borderFlash
  } = useTimer();

  return (
    <View style={styles.container}>
      <View style={styles.main}>
        <Text style={styles.title}>{isCountdown ? 'Countdown' : 'Stopwatch'}</Text>

        <View style={[styles.timerBox, borderFlash && { borderColor: borderFlash, borderWidth: 4 }]}>
          <Text style={styles.time}>{formatTime(time)}</Text>
        </View>

        {isCountdown && (
          <TextInput
            style={styles.input}
            value={inputSeconds}
            onChangeText={setCountdown}
            placeholder="Seconds"
            placeholderTextColor="#aaa"
            keyboardType="numeric"
            editable={!isRunning}
          />
        )}

        <View style={styles.buttons}>
          <Pressable
            onPress={isRunning ? addLap : reset}
            disabled={!isRunning && time === 0}
            style={[styles.btn, { backgroundColor: isRunning ? '#6b7280' : '#555' }]}
          >
            <Text style={styles.btnText}>{isRunning ? 'Lap' : 'Reset'}</Text>
          </Pressable>

          <Pressable
            onPress={startStop}
            disabled={isCountdown && (!inputSeconds || parseInt(inputSeconds) <= 0)}
            style={[styles.btn, { backgroundColor: isRunning ? '#ff3333' : '#33cc33' }]}
          >
            <Text style={styles.btnText}>{isRunning ? 'Stop' : 'Start'}</Text>
          </Pressable>

          <Pressable
            onPress={toggleMode}
            disabled={isRunning}
            style={[styles.btn, { backgroundColor: '#3b82f6' }]}
          >
            <Text style={styles.btnText}>Switch</Text>
          </Pressable>
        </View>

        <FlatList
          data={[...laps].reverse()}
          keyExtractor={(_, i) => i.toString()}
          renderItem={({ item, index }) => (
            <View style={styles.lap}>
              <Text style={styles.lapText}>Lap {laps.length - index}</Text>
              <Text style={styles.lapText}>{formatTime(item)}</Text>
              <Pressable onPress={() => deleteLap(laps.length - 1 - index)}>
                <Text style={styles.deleteText}>Delete</Text>
              </Pressable>
            </View>
          )}
          style={{ width: '90%', marginTop: 20 }}
        />
      </View>

      {flashActive && <View style={styles.flash} pointerEvents="none" />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  main: { flex: 1, alignItems: 'center', paddingTop: 80 },
  title: { color: '#fff', fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  timerBox: { padding: 20, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.1)' },
  time: { fontSize: 72, color: '#fff', fontVariant: ['tabular-nums'] },
  input: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    color: '#fff',
    width: 200,
    padding: 15,
    borderRadius: 10,
    textAlign: 'center',
    marginVertical: 20,
    fontSize: 18
  },
  buttons: { flexDirection: 'row', gap: 20, marginVertical: 20 },
  btn: { paddingHorizontal: 30, paddingVertical: 20, borderRadius: 50, minWidth: 100, alignItems: 'center' },
  btnText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  lap: { flexDirection: 'row', justifyContent: 'space-between', backgroundColor: 'rgba(255,255,255,0.1)', padding: 15, borderRadius: 10, marginVertical: 4, width: '100%' },
  lapText: { color: '#eee', fontSize: 16 },
  deleteText: { color: '#ff4444', fontSize: 14 },
  flash: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(255,0,0,0.8)', zIndex: 999 }
});